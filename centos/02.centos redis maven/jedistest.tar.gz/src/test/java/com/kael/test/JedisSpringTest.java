package com.kael.test;
import static junit.framework.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

public class JedisSpringTest {
	private ApplicationContext app;
	private ShardedJedisPool pool;
	@Before
	public void before() throws Exception {
		app = new ClassPathXmlApplicationContext("applicationContext.xml");
		pool = (ShardedJedisPool)app.getBean("shardedJedisPool");
	}
	@Test
	public void test() {
		ShardedJedis jedis = pool.getResource();
		String keys = "name";
		String value = "snow wolf";
		jedis.del(keys);
		jedis.set(keys,value);
		String v = jedis.get(keys);
		System.out.println(v);
		assertEquals(value,v);
		
		pool.returnResource(jedis);
	}
}

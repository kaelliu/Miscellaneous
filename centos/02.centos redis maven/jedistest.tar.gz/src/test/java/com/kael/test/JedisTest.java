package com.kael.test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.Before;
import org.junit.Test;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisPool;
public class JedisTest {
	private static JedisPool pool;
	private static final int TOTAL_OPERATIONS = 100000;
	@Before
	public void before() {
		ResourceBundle bundle = ResourceBundle.getBundle("redis");
		if(bundle == null)
		{
			throw new IllegalArgumentException("[redis.properties] is not found!");
		}
		JedisPoolConfig config = new JedisPoolConfig();
		config.setMaxActive(Integer.valueOf(bundle
				.getString("redis.pool.maxActive")));
		config.setMaxIdle(Integer.valueOf(bundle
				.getString("redis.pool.maxIdle")));
		config.setMaxWait(Long.valueOf(bundle.getString("redis.pool.maxWait")));
		config.setTestOnBorrow(Boolean.valueOf(bundle
				.getString("redis.pool.testOnBorrow")));
		config.setTestOnReturn(Boolean.valueOf(bundle
				.getString("redis.pool.testOnReturn")));
		pool = new JedisPool(config, bundle.getString("redis.ip"),
				Integer.valueOf(bundle.getString("redis.port")));
	}
	@Test
	public void test() throws InterruptedException
	{
		// get a jedis object
		
		
		// benchmark 01
		//////////////////////////////////////////////////////////
//		long begin = Calendar.getInstance().getTimeInMillis();
//
//		for (int n = 0; n <= TOTAL_OPERATIONS; n++) {
//			String key = "foo" + n;
//			Jedis jedis = pool.getResource();
//			jedis.set(key, "bar" + n);
//			jedis.get(key);
//			pool.returnResource(jedis);
//		}
//
//		long elapsed = Calendar.getInstance().getTimeInMillis() - begin;
//
//
//		System.out.println(((1000 * 2 * TOTAL_OPERATIONS) / elapsed) + " ops");
		////////////////////////////////////////////////////////////
		
		
		// benchmark 02
		////////////////////////////////////////////////////////////
//		long t = System.currentTimeMillis();
//		List<Thread> tds = new ArrayList<Thread>();
//
//        final AtomicInteger ind = new AtomicInteger();
//        for (int i = 0; i < 50; i++) {
//            Thread hj = new Thread(new Runnable() {
//                public void run() {
//                    for (int i = 0; (i = ind.getAndIncrement()) < TOTAL_OPERATIONS;) {
//                        try {
//                            Jedis j = pool.getResource();
//                            final String key = "foo" + i;
//                            j.set(key, key);j.
//                            j.get(key);
//                            pool.returnResource(j);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                    }
//                }
//            });
//            tds.add(hj);
//            hj.start();
//        }
//
//        for (Thread trd : tds)
//            trd.join();
//
//        pool.destroy();
//        long elapsed = System.currentTimeMillis() - t;
//        System.out.println(((1000 * 2 * TOTAL_OPERATIONS) / elapsed) + " ops");
        ////////////////////////////////////////////////////////////
        
        
//		String keys = "name";
//		String value = "snow wolf";
//		jedis.del(keys);
//		// 
//		jedis.set(keys, value);
//		
//		// 
//		String v = jedis.get(keys);
//
//		System.out.println(v);
//
//		// 
//		pool.returnResource(jedis);
//		assertEquals(value, v);
		
		// sorted set test,set's elements is no repeat
		Jedis jedis = pool.getResource();
		jedis.zadd("test01",100d,"Java");
//		jedis.zrem("test01", "java");// remove
		Map<Double, String> scoreMembers = new HashMap<Double, String>();
		scoreMembers.put(90d, "Python");
		scoreMembers.put(80d, "Javascript");
		jedis.zadd("test01", scoreMembers);
		System.out.println("Number of Java users:" + jedis.zscore("test01", "Java"));
		System.out.println(jedis.zrange("test01", 0, 0));
		System.out.println("Number of elements:" + jedis.zcard("test01"));
		System.out.println(jedis.zrevrange("test01", 0, -1));
		System.out.println("Score before zincrby:" + jedis.zscore("test01", "Python"));
		//Incrementing the element score
		jedis.zincrby("test01", 1, "Python");
		System.out.println("Score after zincrby:" + jedis.zscore("test01", "Python"));
		// numbers
//		Jedis jedis = pool.getResource();
//		jedis.set("count", "102");
//		jedis.incr("count");
		
//		System.out.println(jedis.get("count"));
//		pool.returnResource(jedis);
		
		
		assertEquals(1, 1);
	}
}

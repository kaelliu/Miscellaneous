package com.kael.test;

import redis.clients.jedis.Jedis;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Jedis jedis = new Jedis("127.0.0.1");
    	String keys = "name";
    	jedis.del(keys);
    	jedis.set(keys, "snow wolf");
    	String value = jedis.get(keys);
        System.out.println( "Hello World! "+value );
    }
}

package extensions.utils;

public class Commands {
	public static final String LOGINTO="login";
}

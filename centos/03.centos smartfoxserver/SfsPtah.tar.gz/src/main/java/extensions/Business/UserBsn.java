package extensions.Business;

// business for user logic
public class UserBsn {

}

package extensions.main;

import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;
import com.smartfoxserver.v2.extensions.BaseServerEventHandler;

import extensions.utils.Commands;

public class LoginHandler extends BaseClientRequestHandler{

	@Override
	public void handleClientRequest(User arg0, ISFSObject arg1) {
		// TODO Auto-generated method stub
		String userName = arg1.getUtfString("userName");
		String passWord = arg1.getUtfString("passWord");
//		if(userService.checkPassword(userName,passWord) == 1)// extraly match
		{   // spring/mybatis integerated?
			// login success
//			write msg back
			ISFSObject resObj = new SFSObject();
			resObj.putInt("uid", 123);
			resObj.putInt("ok", 1);
			// send to who
			send(Commands.LOGINTO,resObj,arg0);
		}
	}
}

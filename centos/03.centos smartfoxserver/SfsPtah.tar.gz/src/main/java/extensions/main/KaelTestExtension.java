package extensions.main;

import java.util.concurrent.ConcurrentHashMap;

import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.extensions.SFSExtension;

import extensions.DataStructs.UserDto;
import extensions.utils.Commands;

public class KaelTestExtension extends SFSExtension{

	private ConcurrentHashMap<Integer,UserDto> allusers;
	@Override
	public void init() {
		// TODO Auto-generated method stub
		allusers = new ConcurrentHashMap<Integer,UserDto>();
		
		trace("registering handlers");
		addEventHandler(SFSEventType.USER_JOIN_ZONE,UserConnectedHandler.class);
		//addEventHandler(SFSEventType.USER_LOGOUT,UserConnectedHandler.class);
		addEventHandler(SFSEventType.USER_DISCONNECT,UserDisconnectedHandler.class);
		//addEventHandler(SFSEventType.USER_LEAVE_ROOM,UserConnectedHandler.class);
		addRequestHandler(Commands.LOGINTO,LoginHandler.class);
		
	}
	public void destory()
	{
		allusers = null;
		removeRequestHandler(Commands.LOGINTO);
		removeEventHandler(SFSEventType.USER_JOIN_ZONE);
		removeEventHandler(SFSEventType.USER_DISCONNECT);
	}
}

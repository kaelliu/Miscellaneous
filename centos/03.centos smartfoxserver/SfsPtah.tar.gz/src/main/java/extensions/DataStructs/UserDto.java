package extensions.DataStructs;

public class UserDto {
	private int uid;
	private String name;
	private String describe;
	private byte sex;
	private byte icon;
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescribe() {
		return describe;
	}
	public void setDescribe(String describe) {
		this.describe = describe;
	}
	public byte getSex() {
		return sex;
	}
	public void setSex(byte sex) {
		this.sex = sex;
	}
	public byte getIcon() {
		return icon;
	}
	public void setIcon(byte icon) {
		this.icon = icon;
	}
}

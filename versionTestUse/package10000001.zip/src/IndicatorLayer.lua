--///////////////////////////////////////////////////////
--create IndicatorLayer
--///////////////////////////////////////////////////////

IndicatorLayer = class("IndicatorLayer")
IndicatorLayer.__index = IndicatorLayer
IndicatorLayer._widget = nil
IndicatorLayer._uiLayer   = nil
IndicatorLayer._loadMark  = nil
IndicatorLayer._infoLabel = nil
local _blackBar = nil
local _midContainer = nil
local _bigImgUI = nil

local vsize = cc.Director:getInstance():getVisibleSize()
local vorg  = cc.Director:getInstance():getVisibleOrigin() 

--********** lua inherit
function IndicatorLayer.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, IndicatorLayer)
    return target
end

--******** lua createScene function
function IndicatorLayer.create()

    local layer = IndicatorLayer.extend(cc.Layer:create())
    layer:init()
    return layer   
end

--*********** init

function IndicatorLayer:init()

    self._uiLayer = cc.Layer:create()
    self:addChild(self._uiLayer,0,0)

    ------------- ui interface build
    
    _bigImgUI = ccs.GUIReader:getInstance():widgetFromJsonFile("indicatorUI.json") 
    _bigImgUI:setAnchorPoint(cc.p(0,1))
    _bigImgUI:setPosition(cc.p(vorg.x,vsize.height+vorg.y))
    self._widget = _bigImgUI --ccs.GUIReader:getInstance():widgetFromJsonFile("MainUI.json")  --add resouce
    self._uiLayer:addChild(self._widget) 
    
    _blackBar = _bigImgUI:getChildByName("base")
    self._loadMark  = _blackBar:getChildByName("loadMark")
    self._loadMark:setVisible(false)
    self._infoLabel = _blackBar:getChildByName("infoLabel")
    
    _midContainer = _bigImgUI:getChildByName("midContainer")
    _midContainer:setVisible(false)   

    return ture   

end


function IndicatorLayer:setNotSwallowTouch() 
    _bigImgUI:setTouchEnabled(false)
end

function IndicatorLayer:showLoading() 
    self:setLocalZOrder(1000)
    self:setVisible(true)
    self._loadMark:setVisible(true)	
	local rotating = cc.RotateBy:create(1,360)
    self._loadMark:runAction(cc.RepeatForever:create(rotating))
    self._infoLabel:setText("正在加载 ...")
end

function IndicatorLayer:endLoading() 
    self:setLocalZOrder(-1)
    self:setVisible(false)
    self._loadMark:setVisible(false)  
    self._loadMark:stopAllActions()
    self._infoLabel:setText("")

end
function IndicatorLayer:preventTouch() 
    self:setLocalZOrder(1000)
    self:setVisible(false)
end
function IndicatorLayer:disPreventTouch() 
    self:setLocalZOrder(-1)
    self:setVisible(false)
end
function IndicatorLayer:alertInfo(InfoString,isMidle) 
    
    local function show()
        self:setLocalZOrder(1000)
        self:setVisible(true)
        self._infoLabel:setText(InfoString)        
        if isMidle == true then
            _blackBar:setVisible(false)
            _midContainer:setVisible(true)
        end
    end      
    local function dismis() 
        
        self:setVisible(false)
        self._infoLabel:setText("")
        self:setLocalZOrder(-1)
        _blackBar:setVisible(true)
        _midContainer:setVisible(false)
    end    
    local delay = cc.DelayTime:create(1.5)
    local seqc = cc.Sequence:create(cc.CallFunc:create(show),delay,cc.CallFunc:create(dismis))
    
    self:runAction(seqc)
    
end

--url = "183.250.160.9/ussWebservice-test"

--userID   = "100044101"
--userCode = "350203100063"
ruleId   = "10000445"
--displayId= "1"
actFlag  = "20"
--userType = 3
--termType = 2
presentId = "10003493"

function API_checkPlayableTimes(U_ID,U_CODE,RULE_ID,ACT_FlAG)  
    return "http://"..url.."/ws/rs/xmSaleAct/getVipActInfo/userId/"..U_ID.."/userCode/"..U_CODE.."/ruleId/"..RULE_ID.."/actFlag/"..ACT_FlAG

end
function API_exchangePlayTimes_head()  
    return "http://"..url.."/ws/rs/marketPoint/addChangePresentXmCLDS"
end
function API_exchangePlayTimes_plugs(U_ID,U_CODE,TIMES,RULE_ID,PRESENT_ID)  
    return "<TmChange><userId>"..U_ID.."</userId><userCode>"..U_CODE.."</userCode><qtyChange>"..TIMES.."</qtyChange><ruleId>"..RULE_ID.."</ruleId><presentId>"..PRESENT_ID.."</presentId></TmChange>"
end

function API_displayCellInfo()
    return "http://"..url.."/ws/rs/xmSaleAct/getDisplayInfo"
end

function API_startVote(U_ID,U_CODE,DISPLAY_ID,TERM_TYPE)
    return "http://"..url.."/ws/rs/xmSaleAct/saveDisplayVoteResultProc/userId/"..U_ID.."/userCode/"..U_CODE.."/displayId/"..DISPLAY_ID.."/termType/"..TERM_TYPE
end

function API_seeDetailInfo(DISPLAY_ID)  
    return "http://"..url.."/ws/rs/xmSaleAct/getDisplayIdInfo/displayId/"..DISPLAY_ID
end

function API_checkPrizeList(U_ID,startPage,endPage) 
    return "http://"..url.."/ws/rs/xmSaleAct/queryCustUsDisplayVoteTop/userId/"..U_ID.."/startNum/"..startPage.."/endNum/"..endPage 
end


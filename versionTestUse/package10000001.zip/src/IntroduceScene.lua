

--///////////////////////////////////
--create IntroduceScene class 
--///////////////////////////////////
IntroduceScene = class("IntroduceScene")
IntroduceScene.__index = IntroduceScene
IntroduceScene._uiLayer= nil
IntroduceScene._widget = nil
--IntroduceScene._sceneTitle = nil

function IntroduceScene.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, IntroduceScene)
    return target
end

function IntroduceScene:init()

    local vsize = cc.Director:getInstance():getVisibleSize()
    local vOrg  = cc.Director:getInstance():getVisibleOrigin()
    self._uiLayer = cc.Layer:create()
    self:addChild(self._uiLayer)
    
    ------ load UI inteface
    local ui = ccs.GUIReader:getInstance():widgetFromJsonFile("IntrSceneUI.json")  
    ui:setAnchorPoint(0,1)
    ui:setPosition(vOrg.x,vsize.height+vOrg.y)    
    self._widget = ui 
    self._uiLayer:addChild(self._widget) 
    
    -----back button clicked
    local btnBack = ui:getChildByName("btnBack")
    local function back(psender,eventType) 
        if eventType == ccui.TouchEventType.ended then
            playbtnClicked() 
            local mainscene = MainScene:create()
            cc.Director:getInstance():replaceScene(mainscene)       
        end
    end
    btnBack:addTouchEventListener(back)

end  

function IntroduceScene.create()
    local scene = cc.Scene:create()
    local layer = IntroduceScene.extend(cc.Layer:create())
    layer:init()
    scene:addChild(layer)
    return scene   
end


    









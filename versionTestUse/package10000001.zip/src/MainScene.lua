

require("json")

require "Urls"
require "MyprizeScene"
require "IntroduceScene"
require "BigImageScene"
require "DetailScene"

require "IndicatorLayer"

local xml = require("xmlSample").newParser()
-- local parsedXml = xml:ParseXmlText(testXml)
--///////////////////////////////////////////////////////
--create indicator
--////////////////////////////////////////////////////////////////////////////////////////////////////////////
local _indicator = nil

--///////////////////////////////////////////////////////
--create mainScene
--///////////////////////////////////////////////////////

MainScene = class("MainScene")
MainScene.__index = MainScene
MainScene._uiLayer= nil
MainScene._widget = nil
MainScene._sceneTitle = nil
MainScene._exchangeLayer = nil
local _changeContainer = nil
local _mainScene = nil 
local _lblVotes = nil
local _isclose = true
--//////////////////////////////////////////////////////////////
--lua tableView class 
--///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
local TableViewLayer = class("TableViewLayer")
TableViewLayer.__index = TableViewLayer
TableViewLayer._size = nil
local _tbview = nil
local _listArr = {}
local _Arrcounts = 0
local _randNumArr ={}

function TableViewLayer.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, TableViewLayer)
    return target
end

function TableViewLayer.scrollViewDidScroll(view)
    --print("----------scrollViewDidScroll")
end

function TableViewLayer.scrollViewDidZoom(view)
   -- print("scrollViewDidZoom")
end

function TableViewLayer.tableCellTouched(table,cell)
    --print("cell touched at index: " .. cell:getIdx())    
end

function TableViewLayer.cellSizeForTable(table,idx) 
    return  TableViewLayer._size.width/4,TableViewLayer._size.with --TableViewLayer._size.height/8
end

local function onQuit()
    --print("on quit")
end


-----show big pricture call function  >>>>>>>>>>>>>

local function showBigPicture(sender)
    playbtnClicked()
    local blk = cc.Blink:create(0.5,1)
    local function call()
        _mainScene.show(tonumber(sender:getTag()))
    end
    
    sender:runAction(cc.Sequence:create(blk,cc.CallFunc:create(call)))            
 
end


-----see detail of retailers (detail info btn clicked) >>>>>>>>>>>>>
local function seeDetail(sender)
    playbtnClicked() 
    local blk = cc.Blink:create(0.8,2)
    local function call()
        local randIndex = sender:getTag()
        local details =DetailScene.create(randIndex)
        cc.Director:getInstance():replaceScene(details)
    end

    sender:runAction(cc.Sequence:create(blk,cc.CallFunc:create(call)))     
end
----- clicked on vote(support) function  >>>>>>>>>>>>>
local function Split(szFullString, szSeparator)  
    local nFindStartIndex = 1  
    local nSplitIndex = 1  
    local nSplitArray = {}  
    while true do  
        local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)  
        if not nFindLastIndex then  
            nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))  
            break  
        end  
        nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)  
        nFindStartIndex = nFindLastIndex + string.len(szSeparator)  
        nSplitIndex = nSplitIndex + 1  
    end  
    return nSplitArray  
end 

local function castVote(sender,lblTobeset)
    _indicator:preventTouch()
    local blk = cc.Blink:create(0.5,1)
    local function call()
        local votes = tonumber(_lblVotes:getStringValue())
        if votes==nil then            
            _indicator:alertInfo("数据获取失败！")
            _mainScene:refreshVotesAndPoints()            
            return
        end
        
        if votes<1 then
            _indicator:alertInfo("已无投票次数")
            _mainScene:refreshVotesAndPoints()
            return
        end

        _Arrcounts = 0
        --print("cast vote---at----idx-"..sender:getTag()) 
        local xhr = cc.XMLHttpRequest:new()
        xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING        
        xhr.timeout = 10
        local url = API_startVote(userID,userCode,sender:getTag(),termType)
        xhr:open("GET", url) 
        local function onReadyStateChange()
            if xhr.status == 404 then
            --deal with request failed condition
                _indicator:alertInfo("数据获取失败！")
            else
                local parsedXml = xml:ParseXmlText(xhr.response)
                local code = parsedXml.SystemMsg.code:value() 

                local msg = parsedXml.SystemMsg.msg:value() 
                if code =="1" then
                    local strArr = Split(msg,"@")
                    local prizeType = strArr[1]
                    local userID = strArr[2]
                    if prizeType == "0" then
                        _indicator:alertInfo("投票成功",true)                      
                     else
                        _mainScene:showWin(prizeType)
                    end          
                else 
                    _indicator:alertInfo(msg) 
                end

                _mainScene:refreshVotesAndPoints()
                local newVotes =tonumber(lblTobeset:getStringValue()) +1
                lblTobeset:setText(newVotes)
                --TableViewLayer.refreshUIData()
            end
        end
        xhr:registerScriptHandler(onReadyStateChange)
        xhr:send()
    end


    playbtnClicked()
  
    sender:runAction(cc.Sequence:create(blk,cc.CallFunc:create(call)))

    
     
end
----- tableview refresh data  >>>>>>>>>>>>>
local function ranNumberArr() 
    local arr = {}
    local orgArr ={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}
    math.randomseed(tostring(os.time()):reverse():sub(1, 6))
    for i=1,15 do
        local count = table.getn(orgArr)
        local  rand = math.random(1,count)
        table.insert(arr,i,orgArr[rand])
        table.remove(orgArr,rand,orgArr[rand])
    end
    return arr
end

--refresh the votes,the name of each cell,refresh the playable votes
function TableViewLayer.refreshUIData()

        local xhr = cc.XMLHttpRequest:new()
        xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING        
        xhr.timeout = 10
        local url = API_displayCellInfo()
    
        xhr:open("GET", url) 
        local function onReadyStateChange()
            if xhr.status == 404 then
                --deal with request failed condition
               _indicator:alertInfo("数据获取失败！")
            else
            
            _listArr ={}
            local parsedXml = xml:ParseXmlText(xhr.response)
            local items = parsedXml.items:children()
                        
            for k,v in ipairs(items) do
                local displayId = v["@displayId"] 
                local displayName = v["@displayName"] 
                local qtyVote = v["@qtyVote"] 
                table.insert(_listArr,{id = displayId, name = displayName,votes = qtyVote})
             end
            _Arrcounts = table.getn(_listArr)  
            _tbview:reloadData() 
            
            end
        end
        xhr:registerScriptHandler(onReadyStateChange)
        xhr:send()
 
end


----create tableview cells   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
function TableViewLayer.tableCellAtIndex(table, idx)
    local strValue = string.format("%d",idx)
    local cell =nil -- table:dequeueCell()
    local label = nil
    local menu = nil
    table:dequeueCell()
    if nil == cell then
        cell = cc.TableViewCell:new()        
        ---- create a tableview cell by using uicell modle
        local cellModle =  ccs.GUIReader:getInstance():widgetFromJsonFile("MainCell.json") 
        cellModle:setAnchorPoint(0,1)
        cellModle:setPosition(cc.p(0,150))
        cellModle:setTag(100+idx)
        cell:addChild(cellModle)

        if #_randNumArr==15 then            
            --cell nuber by random
            local ranIndex = _randNumArr[idx+1]
            local lblName = cellModle:getChildByName("lblName")
            local lblVotes = cellModle:getChildByName("lblVotes")
            local lblNum   = cellModle:getChildByName("lblNum")

            if _Arrcounts == 15 then
                lblName:setText(_listArr[ranIndex].name)
                lblVotes:setText(_listArr[ranIndex].votes)
                lblNum:setText(_listArr[ranIndex].id)
            end

            --btnImg            
            local btnImg = cellModle:getChildByName("btnImg")
            local spname = "small"..ranIndex..".jpg"
            local spriteImg = cc.Sprite:createWithSpriteFrameName(spname) 
            ------add smalImg
            spriteImg:setAnchorPoint(0,0)
            btnImg:addChild(spriteImg,5,5)
            spriteImg:setTag(ranIndex)          
            
            --btnDetail
            local btnDetail = cellModle:getChildByName("btnDetail")
            btnDetail:setTag(ranIndex)
            ------add spriteDetail
            local spriteDetail = cc.Sprite:createWithSpriteFrameName("btnDetail.png")  
            spriteDetail:setAnchorPoint(0,0)
            btnDetail:addChild(spriteDetail,5,5)
            spriteDetail:setTag(ranIndex)           
           
            --btnVote
            local btnVote = cellModle:getChildByName("btnVote")
            btnVote:setTag(ranIndex)
            ------add spriteVote
            local spriteVote = cc.Sprite:createWithSpriteFrameName("btnVoteN.png")  
            spriteVote:setAnchorPoint(0,0)
            btnVote:addChild(spriteVote,5,5)
            spriteVote:setTag(ranIndex)

            ------ listening event fot sprite clicked----------
            local function onTouchBegan(touch, event)
                local p = event:getCurrentTarget():convertTouchToNodeSpaceAR(touch)
                if cc.rectContainsPoint(event:getCurrentTarget():getBoundingBox(),p) then
                    return true
                end
                return false                
            end
            local function onTouchMoved(touch, event)
                --isMoved = true                               
            end 
            local function onTouchEnded(touch, event)
                local p1 = touch:getStartLocation()
                local p2 = touch:getLocation()
                if math.abs(p2.x-p1.x)>15 or math.abs(p2.y-p1.y)>15 then
                print(">>>>>>.......return touch")
                    return
                else
                
                    print(">>>>>>.......touch moveed")
                end
                if  event:getCurrentTarget() == spriteImg then
                    showBigPicture(spriteImg)
                elseif event:getCurrentTarget() == spriteVote  then
                    castVote(spriteVote,lblVotes)                
                elseif event:getCurrentTarget() == spriteDetail then
                    seeDetail(spriteDetail)
                end
                 
            end  
            
            local listener = cc.EventListenerTouchOneByOne:create()
            listener:setSwallowTouches(false)
            listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN )
            listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED )
            listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED )
            local eventDispatcher = table:getEventDispatcher()
            eventDispatcher:addEventListenerWithSceneGraphPriority(listener, spriteImg)
            eventDispatcher:addEventListenerWithSceneGraphPriority(listener:clone(), spriteDetail)
            eventDispatcher:addEventListenerWithSceneGraphPriority(listener:clone(), spriteVote)
            ----------------------------------------------
            _indicator:disPreventTouch()
        end 

    else
        local cellModle = cell:getChildByTag(100+idx)
        if nil ~= cellModle then
            local ranIndex = _randNumArr[idx+1]
            local lblName = cellModle:getChildByName("lblName")
            lblName:setText(_listArr[ranIndex].name)
            local lblVotes = cellModle:getChildByName("lblVotes")
            lblVotes:setText(_listArr[ranIndex].votes)
            local lblNum   = cellModle:getChildByName("lblNum")
            lblNum:setText(_listArr[ranIndex].id)        
        
        end

    end

    return cell
end

function TableViewLayer.numberOfCellsInTableView(table)
    return 15
end

function TableViewLayer:init(tsize)

    --registerScriptHandler functions must be before the reloadData funtion
    TableViewLayer._size = tsize
    _tbview= cc.TableView:create(tsize,cc.Layer:create())
    --tableView:setAnchorPoint(0,0) --setAnChorPoint will not influnce the tableview at all
    _tbview:setContentSize(tsize)
    _tbview:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)    
    _tbview:setPosition(cc.Director:getInstance():getVisibleOrigin().x+15,cc.Director:getInstance():getVisibleOrigin().y) -- only setposition here can change the tableview position
    _tbview:setDelegate()
    _tbview:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
    self:addChild(_tbview)
    _tbview:registerScriptHandler(TableViewLayer.scrollViewDidScroll,cc.SCROLLVIEW_SCRIPT_SCROLL)
    _tbview:registerScriptHandler(TableViewLayer.scrollViewDidZoom,cc.SCROLLVIEW_SCRIPT_ZOOM)
    _tbview:registerScriptHandler(TableViewLayer.tableCellTouched,cc.TABLECELL_TOUCHED)
    _tbview:registerScriptHandler(TableViewLayer.cellSizeForTable,cc.TABLECELL_SIZE_FOR_INDEX)
    _tbview:registerScriptHandler(TableViewLayer.tableCellAtIndex,cc.TABLECELL_SIZE_AT_INDEX)
    _tbview:registerScriptHandler(TableViewLayer.numberOfCellsInTableView,cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
    
    if _Arrcounts==0 then        
        TableViewLayer.refreshUIData()        
    end  
    _randNumArr = ranNumberArr()   
    _tbview:reloadData()  
     

    return true
end

function TableViewLayer.create(tsize)

    local layer = TableViewLayer.extend(cc.Layer:create())
    if nil ~= layer then
        layer:init(tsize)
    end

    return layer
end


--///////////////////////////////////////////////////////
--create mainScene
--///////////////////////////////////////////////////////

--********** lua inherit
function MainScene.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, MainScene)
    return target
end

--******** lua createScene function
function MainScene.create()
    local scene = cc.Scene:create()
    local layer = MainScene.extend(cc.Layer:create())
    layer:init()
    scene:addChild(layer)
    return scene   
end

--*********** init

local _scrollView = nil
function MainScene:init()

    ---- add indicator
    _indicator = IndicatorLayer.create()     --createIndicator()
    self:addChild(_indicator,0,0)
    _indicator:disPreventTouch()
    
    local vsize = cc.Director:getInstance():getVisibleSize()
    local vorg  = cc.Director:getInstance():getVisibleOrigin()  
    
    ----add exchange ui
    self._exchangeLayer = cc.Layer:create()   

    
    self:addChild(self._exchangeLayer,0,0)
    local exchangeUI = ccs.GUIReader:getInstance():widgetFromJsonFile("exchangeUI.json") 
    exchangeUI:setAnchorPoint(cc.p(0,1))
    exchangeUI:setPosition(cc.p(vorg.x,vsize.height+vorg.y-80))
    self._exchangeLayer:addChild(exchangeUI) 
        
    _changeContainer = exchangeUI:getChildByName("changeContainer")
    local textContainer =  _changeContainer:getChildByName("textTimes")
    
    ------------- ui interface build
    self._uiLayer = cc.Layer:create()
    self:addChild(self._uiLayer,2,2)
    

    
    _mainScene = self

    ----add main ui   
    local ui = ccs.GUIReader:getInstance():widgetFromJsonFile("MainSceneUI.json") 
    ui:setAnchorPoint(cc.p(0,1))
    ui:setPosition(cc.p(vorg.x,vsize.height+vorg.y))
    self._widget = ui --ccs.GUIReader:getInstance():widgetFromJsonFile("MainUI.json")  --add resouce
    self._uiLayer:addChild(self._widget)   
    
    
    local tbviewContainer = ui:getChildByName("tableViewContainer")       
    
    ----------- EXChange view and buttons Events
    local topcontainer = ui:getChildByName("topContainer") 
    _lblVotes = topcontainer:getChildByName("lblVotes")
    

    --local txtTimes = _changeContainer:getChildByName("textTimes")

    local btnCancel = _changeContainer:getChildByName("btnCancel")
    local btnConfirm = _changeContainer:getChildByName("btnConfirm")
    local btnChange = topcontainer:getChildByName("btnChange")
    local btnBack = topcontainer:getChildByName("btnBack")  
    
    --------back button return to root controller
    local function backToRoot(sender, eventType) 
    	if eventType == ccui.TouchEventType.ended then
            playbtnClicked() 
    	end
    end
    btnBack:addTouchEventListener(backToRoot)
   
    -------------------textfile editbox------------
    local times = nil
    local editBoxSize = cc.size(120, 35)
    local box = nil
    
    -- top
    box = cc.EditBox:create(editBoxSize, cc.Scale9Sprite:createWithSpriteFrameName("imgnil.png"))
    local p =cc.p(textContainer:getPositionX(),textContainer:getPositionY())
    local p2 = self._exchangeLayer:convertToNodeSpace(p)
    --print("********p"..p.x..","..p.y.."p2"..p2.x..","..p2.y)
    box:setPosition(cc.p(vorg.x+216, vorg.x+vsize.height-280))
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()

    box:setFontName("Paint Boy")
    box:setAnchorPoint(0,1)
    box:setFontSize(20)
    box:setFontColor(cc.c3b(255,0,0))
    box:setPlaceHolder("请输入...")
    box:setPlaceholderFontColor(cc.c3b(255,255,255))
    box:setMaxLength(8)
    box:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE )
    box:setInputMode(cc.EDITBOX_INPUT_MODE_NUMERIC)
    
    --------textfiled delegate methords
    local function editBoxTextEventHandle(strEventName,pSender)
        local edit = pSender
        local strFmt 
        if strEventName == "began" then
            --print("----box bengan")
        elseif strEventName == "ended" then
            --print("----box ended")
            times =tonumber(box:getText())
            local result1 = string.find(box:getText(),'%a') --any letters
            local result2 = string.find(box:getText(),'%p') --any punctuation
            local result3 = string.find(box:getText(),'%s') --space

            if result1~=nil or result2~=nil or result3~=nil then
                _indicator:alertInfo("请输入正整数") 
                times = nil 
                return
            end

        elseif strEventName == "return" then
            --print("----box return")
        elseif strEventName == "changed" then

        end
    end

    --Handler
    box:registerScriptEditBoxHandler(editBoxTextEventHandle)
    self._exchangeLayer:addChild(box)
    --textContainer:addChild(box)

    -------- close change view 
    local function closeChangeView(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            playbtnClicked() 
            self._exchangeLayer:setLocalZOrder(0)
            box:setText("")
            _isclose = true
        end
    end            
    btnCancel:addTouchEventListener(closeChangeView) 
    
    --------btnChange clicked --->check playable times

    _mainScene:refreshVotesAndPoints() -- call this here to refresh point label
    --_indicator:disPreventTouch()

    local function popExChangeView(sender,eventType)
        if eventType == ccui.TouchEventType.ended then 
            playbtnClicked() 
            if userType == 1 then -- 零售用户不可见 exchange view
                return
            end   
            if _isclose == true then
                self._exchangeLayer:setLocalZOrder(50)
                box:setText("")
                _mainScene:refreshVotesAndPoints()
            else
                self._exchangeLayer:setLocalZOrder(0)                
            end
            
            _isclose = not _isclose
        end
    end

    btnChange:addTouchEventListener(popExChangeView) 
    
    --------btnConfirm clicked
    local function confirmExchangePoints()

         
        local xhr = cc.XMLHttpRequest:new()
        xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING        
        xhr.timeout = 10
        local url = API_exchangePlayTimes_head()
        local postData = API_exchangePlayTimes_plugs(userID,userCode,times,ruleId,presentId)
        --xhr.setRequestHeader("Content-Length",string.len(postData))
        
        xhr:setRequestHeader("CONTENT-TYPE", "application/soap+xml;charset=utf-8")
        xhr:open("POST", url) 
        local function onReadyStateChange()
            if xhr.status == 404 then
                --deal with request failed condition
                _indicator:alertInfo("数据获取失败！")
                box:setText("")
            else                
                times = nil                
                local parsedXml = xml:ParseXmlText(xhr.response)                
                local code = tonumber(parsedXml.SystemMsg.code:value())
                --print("---qtyChance---******-----"..xhr.response.."---******----->>"..code)
                if code == 1 then
                    _indicator:alertInfo("成功兑换"..times.."票")
                    --local pointValue =  parsedXml.SystemMsg.value:value()
                    _mainScene:refreshVotesAndPoints() --should refresh votes label again
                elseif code == -5 then
                    _indicator:alertInfo("活动时间内才可兑换")
                end  
            end
        end
        xhr:registerScriptHandler(onReadyStateChange)
        xhr:send(postData)
        
    end
    --confirmExchangePoints()
    local function confirm(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            playbtnClicked() 
            if _changeContainer:getZOrder() == 0 then
            	return
            end
           
            local lblChangeAble = _changeContainer:getChildByName("lblChangeble")
            local changableTimes = tonumber(lblChangeAble:getStringValue())
            --times = tonumber(box:getText())
            if times == nil then
                _indicator:alertInfo("请输入有效票数")
                return
            elseif changableTimes<1 or times>changableTimes then
                _indicator:alertInfo("您的积分不够")
                return
            else
                confirmExchangePoints()
                box:setText("")
            end
            self._exchangeLayer:setLocalZOrder(0) 
            _isclose = true
       
        end
    end 
    
    btnConfirm:addTouchEventListener(confirm) 
    
    --------------create a tableview
    local tsize = cc.size(vsize.width,vsize.height-400) -- data 260 here is wrong, correctly it should be the boundingbox.height of topcontainer
    -- tsize decide both the size and position of the tableview when it is created,
    --when a tableview been created, it's default anchorpoint and potision are (0,0),
    --and the anchorpoint can not be changed by reset it,only position can be reset
    --tsize = cc.size(vsize.with,vsize.height-topcontainer:getBoundingBox().size.height)-- getBoundingBox() is a nill value ,error!!
    
    local tpx = topcontainer:getPositionX()
    local tpy = topcontainer:getPositionY()
    local _tableView = TableViewLayer.create(tsize)
    --_tableView:setAnchorPoint(cc.p(0,0)) -- this does not effect at all
    --_tableView:setPosition(cc.p(tpx,tpy))
    self._uiLayer:addChild(_tableView)
    --self._uiLayer:addChild(_tableView)

    ------- btnMyprize clicked
    local btnMyprize = ui:getChildByName("btnMyprize")     
    local function goMyprizeScene(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            playbtnClicked() 
            local prizescene = MyprizeScene.create()
            cc.Director:getInstance():replaceScene(prizescene)           
        end     
    end
    btnMyprize:addTouchEventListener(goMyprizeScene) 
    
    ------- btnIntroduce clicked
    local btnIntroduce = ui:getChildByName("btnIntroduce")     
    local function goIntroduceScene(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            playbtnClicked() 
            local introduceS = IntroduceScene.create()
            cc.Director:getInstance():replaceScene(introduceS)           
        end     
    end
    btnIntroduce:addTouchEventListener(goIntroduceScene) 
  
    --------------------------- 

    
    
    
    return ture   

end

------ class functions >>>>>>>>>>>>
-- when cell small img button clicked,show big picture of it
function MainScene.show(index)  
    local bgsc = BigImageScene.create(index)
    cc.Director:getInstance():replaceScene(bgsc)
    
end

function MainScene:refreshVotesAndPoints()  

    local lblCurPoints = _changeContainer:getChildByName("lblCurPoints")
    local lblChangeAble = _changeContainer:getChildByName("lblChangeble")
    
    local xhr = cc.XMLHttpRequest:new()
    xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING        
    xhr.timeout = 10
    local url = API_checkPlayableTimes(userID,userCode,ruleId,actFlag) --API_displayCellInfo()
    
    --print(">>>>>>>>"..url)
    xhr:open("GET", url) 
    local function onReadyStateChange()
        if xhr.status == 404 then
            --deal with request failed condition
            lblCurPoints:setText("0") 
            lblChangeAble:setText("0") 
            _lblVotes:setText("0")
            _indicator:alertInfo("数据获取失败！")
        else
            local parsedXml = xml:ParseXmlText(xhr.response)
            --cclog("*********respose=="..xhr.response)
            local qtyChance = parsedXml.items.item["@qtyChance"]--可玩游戏次数
            local maxQtyExc = parsedXml.items.item["@maxQtyExc"] --可兑换次数
            local qtyValidPoints = parsedXml.items.item["@qtyValidPoints"] --可用积分

            _lblVotes:setText(""..qtyChance)
            lblChangeAble:setText(""..maxQtyExc)
            lblCurPoints:setText(""..qtyValidPoints) 
 
            
        end
    end
    xhr:registerScriptHandler(onReadyStateChange)
    xhr:send()

end

--show the prize type after cast vote
function MainScene:showWin(typeId) 
    --------show win prize or dismis----------
    _indicator:disPreventTouch()
    local vsize = cc.Director:getInstance():getVisibleSize()
    local vorg  = cc.Director:getInstance():getVisibleOrigin() 
    local showWinUI = ccs.GUIReader:getInstance():widgetFromJsonFile("showWinUI.json")
    --showWinUI:setTouchEnabled(true)
    showWinUI:setAnchorPoint(cc.p(0,1))
    showWinUI:setPosition(cc.p(vorg.x,vsize.height+vorg.y))
    local container = showWinUI:getChildByName("container")
    local btnCheckTo = container:getChildByName("btnCheck")
    local btnOk = container:getChildByName("btnOk")
    --container:setTouchEnabled(true)
    
    local prizeName = nil
    if typeId =="1" then
        prizeName = "dtxj.png"
    elseif typeId == "2" then
        prizeName = "txj.png"
    else
    	prizeName = "tyj.png"
    end

    local imgPrize = ccui.ImageView:create(prizeName,1)
    --local s = 500/imgPrize:getContentSize().width
    imgPrize:setAnchorPoint(0,0)
    --imgPrize:setScale(s,s)
    container:addChild(imgPrize,0,-1)
    self._uiLayer:addChild(showWinUI,1000,1000) 

    local function goMyprizeScene(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self._uiLayer:removeChild(showWinUI) 
            local prizescene = MyprizeScene.create()
            cc.Director:getInstance():replaceScene(prizescene)           
        end     
    end
    btnCheckTo:addTouchEventListener(goMyprizeScene)

    local function dismisPrize(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self._uiLayer:removeChild(showWinUI)          
        end
    end
    btnOk:addTouchEventListener(dismisPrize)
 
end





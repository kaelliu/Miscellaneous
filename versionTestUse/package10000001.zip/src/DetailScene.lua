
--///////////////////////////////////////////////////////
--create mainScene
--///////////////////////////////////////////////////////
require "IndicatorLayer"

DetailScene = class("DetailScene")
DetailScene.__index = DetailScene
DetailScene._widget = nil
DetailScene._showLayer = nil
local _indicator = nil

local _randIndex = 0
local xml = require("xmlSample").newParser()

--///////////////////////////////////////////////////////
--create mainScene
--///////////////////////////////////////////////////////



--********** lua inherit
function DetailScene.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, DetailScene)
    return target
end

--******** lua createScene function
function DetailScene.create(idx)
    --cclog("idx:"..idx)
    local scene = cc.Scene:create()
    local layer = DetailScene.extend(cc.Layer:create())
    _randIndex = idx
    layer:init()
    scene:addChild(layer)
    return scene   
end

--*********** init
local _scrollView = nil
function DetailScene:init()

    _indicator = IndicatorLayer.create()     --createIndicator()
    _indicator:setNotSwallowTouch()
    self:addChild(_indicator,0,0)
    
    ---- add indicator
    self._showLayer = cc.Layer:create()
    self:addChild(self._showLayer,0,0)
 

    ------------- ui interface build
    local vsize = cc.Director:getInstance():getVisibleSize()
    local vorg  = cc.Director:getInstance():getVisibleOrigin()     
        local bigImgUI = ccs.GUIReader:getInstance():widgetFromJsonFile("DetailSceneUI.json") 
        bigImgUI:setAnchorPoint(cc.p(0,1))
        bigImgUI:setPosition(cc.p(vorg.x,vsize.height+vorg.y))
        self._widget = bigImgUI --ccs.GUIReader:getInstance():widgetFromJsonFile("MainUI.json")  --add resouce
    self._showLayer:addChild(self._widget) 

    local function back(sender,eventType) 
        if eventType == ccui.TouchEventType.ended then
            playbtnClicked() 
            local mainsc = MainScene:create()
            cc.Director:getInstance():replaceScene(mainsc)
        end

    end
    local topBar = bigImgUI:getChildByName("topBar")
    local btnBack = topBar:getChildByName("btnBack")
    btnBack:addTouchEventListener(back)
    
    local bgContainer = bigImgUI:getChildByName("bgContainer")

    local imgTxtBg = bgContainer:getChildByName("imgTxtBg")
    local imgBg = bgContainer:getChildByName("imgBg")
    local scaleY = 1 + vsize.height/vsize.width - 1.5
    imgTxtBg:setScaleY(scaleY)
    imgTxtBg:setPositionY(imgBg:getPositionY()-imgBg:getContentSize().height/2 - imgTxtBg:getBoundingBox().height/2)
    
    
    local lblName     = bgContainer:getChildByName("lblName")
    local lblNum      = bgContainer:getChildByName("lblNum")
    local lblContent  = bgContainer:getChildByName("lblContent")

--------------- load info request ------
    local function loadDetailInfo() 
        _indicator:showLoading()
        local xhr = cc.XMLHttpRequest:new()
        xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING        
        xhr.timeout = 10
        
        local url = API_seeDetailInfo(_randIndex)
        xhr:open("GET", url) 
        local function onReadyStateChange()
            _indicator:endLoading()
         if xhr.status == 404 then
            --deal with request failed condition
                _indicator:alertInfo("数据读取失败!")
            else
                local parsedXml = xml:ParseXmlText(xhr.response)
                local custLicenceCode = parsedXml.items.item["@custLicenceCode"]
                local custName = parsedXml.items.item["@custName"]
                local remark = parsedXml.items.item["@remark"]
                
                lblNum:setText(custLicenceCode)
                lblName:setText(custName)
                lblContent:setText(remark)
              

            end
         end
        xhr:registerScriptHandler(onReadyStateChange)
        xhr:send()
    end    
    loadDetailInfo()


    return ture   

end




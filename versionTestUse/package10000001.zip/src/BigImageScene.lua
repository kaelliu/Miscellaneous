--require("json")
--///////////////////////////////////////////////////////
--create mainScene
--///////////////////////////////////////////////////////

BigImageScene = class("BigImageScene")
BigImageScene.__index = BigImageScene
BigImageScene._widget = nil
BigImageScene._showLayer = nil
BigImageScene._uiLayer = nil


local _randIdx = nil
--///////////////////////////////////////////////////////
--create mainScene
--///////////////////////////////////////////////////////



--********** lua inherit
function BigImageScene.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, BigImageScene)
    return target
end

--******** lua createScene function
function BigImageScene.create(idx)
    local scene = cc.Scene:create()
    local layer = BigImageScene.extend(cc.Layer:create())
    _randIdx = idx
    layer:init()
    scene:addChild(layer)
    return scene   
end

--*********** init
local _scrollView = nil
function BigImageScene:init()

    
    self._uiLayer = cc.Layer:create()
    self:addChild(self._uiLayer,0,0)
    
    self._showLayer = cc.Layer:create()
    self:addChild(self._showLayer,1,1)
    local vsize = cc.Director:getInstance():getVisibleSize()
    local vorg  = cc.Director:getInstance():getVisibleOrigin()   
  
  

    ----set scrollview
    --local uiScrollView = bigImgUI:getChildByName("scrollView")
    _scrollView = cc.ScrollView:create()
    local container = nil
    if nil ~= _scrollView then
        _scrollView:setViewSize(cc.size(640,vsize.height-70))
        _scrollView:setContentSize(cc.size(640*2,880*2))
        _scrollView:setAnchorPoint(0,0)
        _scrollView:setPosition(cc.p(vorg.x ,vorg.y))
        _scrollView:setScale(1.0)
        _scrollView:ignoreAnchorPointForPosition(false)

        _scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_BOTH )
        _scrollView:setClippingToBounds(true)
        _scrollView:setBounceable(true)
        _scrollView:setDelegate()
                
        cc.FileUtils:getInstance():addSearchResolutionsOrder("res/big")
        local sname = "big".._randIdx..".jpg"
        local tx = cc.Director:getInstance():getTextureCache():addImage(sname)
        container =  cc.Sprite:createWithTexture(tx)
        local wid = container:getContentSize().width
        if wid<640 then
        	container:setScale(640/wid)
        end
        
        if nil ~= container then
            _scrollView:setContainer(container)
            _scrollView:updateInset()
            container:setPosition(cc.p(vorg.x ,vorg.y+(vsize.height-container:getBoundingBox().height)/2 ))
        end



    end
    self._showLayer:addChild(_scrollView)
  
    ------------- ui interface build  
    local bigImgUI = ccs.GUIReader:getInstance():widgetFromJsonFile("bigImgUI.json") 
    bigImgUI:setAnchorPoint(cc.p(0,1))
    
    
    bigImgUI:setPosition(cc.p(vorg.x,vsize.height+vorg.y))
    self._widget = bigImgUI --ccs.GUIReader:getInstance():widgetFromJsonFile("MainUI.json")  --add resouce
    self._showLayer:addChild(self._widget) 


    local btnBack = bigImgUI:getChildByName("btnBack")
    btnBack:setTouchEnabled(true)
    local function close(sender, eventType) 
        if eventType == ccui.TouchEventType.ended then
            playbtnClicked() 
            local mainsc = MainScene:create()
            cc.Director:getInstance():replaceScene(mainsc)
        end

    end
    btnBack:addTouchEventListener(close)
 
    return ture   

end




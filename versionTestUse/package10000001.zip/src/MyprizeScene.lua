
--///////////////////////////////////////////////////////////////////////////////////////////////////////
--lua tableView class 
--///////////////////////////////////////////////////////////////////////////////////////////////////////--require "src/ExtensionTest/CocosBuilderTest"
local TableViewLayer = class("TableViewLayer")
TableViewLayer.__index = TableViewLayer
TableViewLayer._size = nil
local _listArr ={}

local xml = require("xmlSample").newParser()
-------------request----
local startPage = 1
local items  = {}
local _indicator = nil

local table_insert = table.insert
local table_getn = table.getn
local tabel_size = 10
local function checkPrizeList()
    local xhr = cc.XMLHttpRequest:new()
    xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING        
    xhr.timeout = 10
    if tabel_size < startPage then 
        return 
    end
    local url = API_checkPrizeList(userID,startPage,startPage+9)
    xhr:open("GET", url) 
    local function onReadyStateChange()
        if xhr.status == 404 then
            --deal with request failed condition
            _indicator:alertInfo("数据获取失败")
        else
            startPage = startPage + 10
            local parsedXml = xml:ParseXmlText(xhr.response)
            --local items_new = {{giftName = "小苹果1",aswDate = "2014-0701"}}
            local items_new = parsedXml.items:children()
            if table_getn(items_new) <= 0 then
                return
            end
            for k,v in ipairs(items_new) do
                table_insert(items,v)
            end
           -- print("response>>>>>>>>>"..xhr.response)
            --for k,v in ipairs(items) do
            -- local displayId = v["@giftName"] 
            --local displayName = v["@aswDate"] 
            --local qtyVote = v["@qtyVote"] 
            -- table.insert(_listArr,{prize = displayName,date = qtyVote})
            -- end
            TableViewLayer:responCallBack()
            -- print("list>>>>>>>>".._listArr.prize)
        end
    end
    xhr:registerScriptHandler(onReadyStateChange)
    xhr:send()
end 
---------------

function TableViewLayer.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, TableViewLayer)
    return target
end

function TableViewLayer.dragRefreshTableView()
    --cclog("checkPrizeList")
    checkPrizeList()
end

function TableViewLayer.scrollViewDidScroll(view)
   -- print("scrollViewDidScroll")
    --TableViewLayer.dragRefreshTableView();
end

function TableViewLayer.scrollViewDidZoom(view)
   -- print("scrollViewDidZoom")
end

function TableViewLayer.tableCellTouched(table,cell)
   -- print("cell touched at index: " .. cell:getIdx())

end

function TableViewLayer.cellSizeForTable(table,idx) 
    return  70,610 --TableViewLayer._size.height/8
end

local function onQuit()
    --print("on quit")
end

local vsize = cc.Director:getInstance():getVisibleSize()
local vOrg  = cc.Director:getInstance():getVisibleOrigin()

function TableViewLayer.tableCellAtIndex(table, idx)
    local strValue = string.format("%d",idx)

    local cell = table:dequeueCell()
    local label = nil
    local menu = nil
    if nil == cell then
        cell = cc.TableViewCell:new()

        local ui = ccs.GUIReader:getInstance():widgetFromJsonFile("prizeCell.json")  
        ui:setAnchorPoint(0,1)
        ui:setPosition(vOrg.x,80)
        cell:addChild(ui)   
        local item = items[idx+1]
        if item == nil then 
            return
        end
        ---- set lable info. for each cell
        local container = ui:getChildByName("cell")
        local lblPrize = container:getChildByName("lblPrize")
        lblPrize:setText(item["@giftName"])
        --lblPrize:setText(item.giftName)
        local lblDate = container:getChildByName("lblDate")
        lblDate:setText(item["@aswDate"])
        --lblDate:setText(item.aswDate)
        tabel_size = tonumber(item["@totalNum"]) 
    else
        local item1 = cell:getChildByTag(123)
        if nil ~= item1 then

        end

    end

    return cell
end

function TableViewLayer.numberOfCellsInTableView()

    return table_getn(items)
end
local function onTouchBegan(touch, event)
    return true
end
local function onTouchMoved(touch, event)

end
local isNew = false
local function onTouchEnded(touch, event)
    local p = touch:getStartLocation();
    local pend = touch:getLocation();
    if (pend.y-p.y)>300 then
        local ratio = math.abs(pend.y-p.y)/(math.abs(pend.x-p.x)+5);
        if ratio>1 then
            checkPrizeList();
        end
        --    elseif pend.y - p.y <-100 then
        --        isNew = true
        --        checkPrizeList();
    end
end
local tableView = nil
function TableViewLayer:init(tsize,tposition)

    --registerScriptHandler functions must be before thse reloadData funtion
    TableViewLayer._size = tsize
    tableView = cc.TableView:create(tsize,cc.Layer:create())
    --tableView:setAnchorPoint(0,0)
    tableView:setContentSize(tsize)
    tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
    tableView:setPosition(cc.Director:getInstance():getVisibleOrigin().x,cc.Director:getInstance():getVisibleOrigin().y)
    tableView:setDelegate()
    tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
    self:addChild(tableView)
    tableView:registerScriptHandler(TableViewLayer.scrollViewDidScroll,cc.SCROLLVIEW_SCRIPT_SCROLL)
    tableView:registerScriptHandler(TableViewLayer.scrollViewDidZoom,cc.SCROLLVIEW_SCRIPT_ZOOM)
    tableView:registerScriptHandler(TableViewLayer.tableCellTouched,cc.TABLECELL_TOUCHED)
    tableView:registerScriptHandler(TableViewLayer.cellSizeForTable,cc.TABLECELL_SIZE_FOR_INDEX)
    local listener = cc.EventListenerTouchOneByOne:create()
    listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN )
    listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED )
    listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED )
    local eventDispatcher = tableView:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, tableView)
    return true
end

function TableViewLayer:responCallBack()
    tableView:registerScriptHandler(TableViewLayer.tableCellAtIndex,cc.TABLECELL_SIZE_AT_INDEX)
    tableView:registerScriptHandler(TableViewLayer.numberOfCellsInTableView,cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
    tableView:reloadData()   
end

function TableViewLayer.create(tsize,tposition)

    local layer = TableViewLayer.extend(cc.Layer:create())
    if nil ~= layer then
        layer:init(tsize,tposition)
    end

    return layer
end


--///////////////////////////////////
--create MyprizeScene class 
--///////////////////////////////////
MyprizeScene = class("MyprizeScene")
MyprizeScene.__index = MyprizeScene
MyprizeScene._uiLayer= nil
MyprizeScene._widget = nil
MyprizeScene._sceneTitle = nil

function MyprizeScene.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, MyprizeScene)
    return target
end

function MyprizeScene.create()
    local scene = cc.Scene:create()
    local layer = MyprizeScene.extend(cc.Layer:create())
    layer:init()
    scene:addChild(layer)
    return scene   
end


function MyprizeScene:init()

    local vsize = cc.Director:getInstance():getVisibleSize()
    local vOrg  = cc.Director:getInstance():getVisibleOrigin()
    self._uiLayer = cc.Layer:create()
    self:addChild(self._uiLayer)
    
    _indicator = IndicatorLayer:create()
    _indicator:setNotSwallowTouch()
    self._uiLayer:addChild(_indicator)

    local ui = ccs.GUIReader:getInstance():widgetFromJsonFile("MyprizeSceneUI.json")  
    ui:setAnchorPoint(0,1)
    ui:setPosition(vOrg.x,vsize.height+vOrg.y)    
    self._widget = ui 
    self._uiLayer:addChild(self._widget) 
    --    
    --
    --
    --    -----create a tableview
    --    local tbview = ui:getChildByName("tableViewContainer")   
    --    local topContainer = ui:getChildByName("topContainer")
    local tsize = cc.size(vsize.width,vsize.height-420)  -- 300 should be replaced by topcontainer.boundingbox.height
    local _tableView = TableViewLayer.create(tsize,cc.p(0,0))
    --NOTE: nomatter you change the tpx/tpy, you can not change the position of _tableview
    -- but if you change the tisize, the size of _tableview will be changed   
    self._uiLayer:addChild(_tableView)

    -----back button clicked
    -----back button clicked
    local btnBack = ui:getChildByName("btnBack")
    local function back(psender,eventType) 
        if eventType == ccui.TouchEventType.ended then
            playbtnClicked() 
            local mainscene = MainScene:create()
            tabel_size = 10
            startPage = 1
            cc.Director:getInstance():replaceScene(mainscene)       
        end
    end
    btnBack:addTouchEventListener(back)

    checkPrizeList()

end  



require "Cocos2d"
require "Cocos2dConstants"

--resource path
--cc.FileUtils:getInstance():addSearchResolutionsOrder("src")
--cc.FileUtils:getInstance():addSearchResolutionsOrder("res")

cc.SpriteFrameCache:getInstance():addSpriteFrames("res.plist","res.png")
-- cclog
cclog = function(...)
    print(string.format(...))
end

require "MainScene"

function playbtnClicked() 
    print("btn clicked sound ------")
    cc.SimpleAudioEngine:getInstance():playEffect("res/clicked.mp3")
end

local function game10000001()
    local mainscene = MainScene.create()
    return mainscene
end

local gm = game10000001()
return gm

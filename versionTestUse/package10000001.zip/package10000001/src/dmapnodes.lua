local dmapnodes={}

function dmapnodes:test(abc)
    print (abc)
end

return dmapnodes
local staff = class("Staff")

staff.constant_varible = 100

function staff:ctor()
    -- local varible 
    self.hp1 = 1
end

local function private_staff(v)
    return v * 3.1415926 
end

function staff:dostaff(__vala,__valb,__valc)
    -- class
    self.hp1 = private_staff(self.constant_varible * (__valb + __valc + __vala))
    return self.hp1
end

--function staff.dodot(vala,valb,valc)
--    print(vala+valb+valc)
--end

return staff
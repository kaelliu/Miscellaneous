local mgr ={}

function mgr.init(obj,filename)
    obj.sprite=cc.Sprite:create(filename)
end

return mgr
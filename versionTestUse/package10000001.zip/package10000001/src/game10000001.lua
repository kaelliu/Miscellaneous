require "Cocos2d"
require "Cocos2dConstants"
require("json")
require("socket.core")
require("src.functions")
require "src/testResource"
local Staff = require("src.modstaff")
--local dnodes = require("src.dmapnodes_ex")
-- cclog
cclog = function(...)
    print(string.format(...))
end
  
-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
    cclog("----------------------------------------")
    cclog("LUA ERROR: " .. tostring(msg) .. "\n")
    cclog(debug.traceback())
    cclog("----------------------------------------")
end

local function main()
    collectgarbage("collect")
    -- avoid memory leak
    collectgarbage("setpause", 100)
    local valstep = collectgarbage("setstepmul", 1000)
   
    -- set frame for test ui layout
    --cc.Director:getInstance():getOpenGLView():setFrameSize(480,320)
    --[[
    a:b(c) equal a.b(a,c) a is a table,and b is a function
    comment by kael
    module can be write like:
   
    local _M = {}
    function _M.dostaff(self,a,b,c)
        return private_staff(a+b*c)
    end
    
    function _M:dostaff(a,b,c)
        return private_staff(a+b*c)
    end
    
    -- static function like
    function _M.dot_staff(a,b,c)
        return private_staff(a+b*c)
    end
    
    local function private_staff(v)
        return v * 3.1415926 
    end
    return _M
    
    then call
    local staff = require("staff") -- _M 
    local result = staff:dostaff(1,2,3)
    or local result = staff.dostaff(staff,1,2,3)
    
    The colon is for implementing methods that pass self as the first parameter.
    So x:bar(3,4)should be the same as x.bar(x,3,4)
    
    metatable通过其包含的函数来给所挂接的table定义一些特殊的操作
    __index: 定义当table中不存在的key值被试图获取时的行为
    __add: 定义所挂接table的加法操作
    
    cls.__cname = classname
    cls.__ctype = 2 -- lua
    cls.__index = cls
    function cls.new(...)
        local instance = setmetatable({}, cls) -- 将cls挂接成为{}的操作
        instance.class = cls
        instance:ctor(...)
        return instance
    end
    
    ]]--
 
    local result1234 = Staff.new()--require("src.modstaff")--Staff.new()
    local result1235 = Staff.new()
--    local fin = result1234.dostaff(1,2,3)
    local fin2 = result1234:dostaff(1,3,4)
    local fin3 = result1235:dostaff(3,3,4)
    --cc.Director:getInstance():getOpenGLView():setFrameSize(480,320)
--    cc.Director:getInstance():getOpenGLView():setDesignResolutionSize(960,640,cc.Director:getOpenGLView())
    --result1234.dodot(1,3,4)
    local modk = require("src.moduletest")
    --modk.dostaff(modk,2,3)
    modk:dostaff(2,3)
    print(modk.helper(3,2))
    
    local nodx = require("src.dmapnodes")
    nodx.blabla=12
    nodx:test(3333)
    
    local nody = require("src.dmapnodes")
    nody.blabla=125
    nody:test(33334)

    print(string.formatNumberThousands(932))
    
	--cc.FileUtils:getInstance():addSearchResolutionsOrder("src");
	--cc.FileUtils:getInstance():addSearchResolutionsOrder("res");
	cc.FileUtils:getInstance():addSearchPath("src");
	cc.FileUtils:getInstance():addSearchPath("res");
    --cc.FileUtils:getInstance():addSearchResolutionsOrder("res/fonts");
	local schedulerID = 0
    --support debug
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) or 
       (cc.PLATFORM_OS_ANDROID == targetPlatform) or (cc.PLATFORM_OS_WINDOWS == targetPlatform) or
       (cc.PLATFORM_OS_MAC == targetPlatform) then
        cclog("result is ")
		--require('debugger')()
        
    end
    require "src/hello2"
    cclog("result is " .. myadd(1, 1))
    
    ---------------

    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()
    print("vs width:"..visibleSize.width.." vs height:"..visibleSize.height)
    print("origin x:"..origin.x.." origin y:"..origin.y)
    -- add the moving dog
    local function creatDog()
        local frameWidth = 105
        local frameHeight = 95
        
        -- create dog animate
        local textureDog = cc.Director:getInstance():getTextureCache():addImage("dog.png")
        local rect = cc.rect(0, 0, frameWidth, frameHeight)
        local frame0 = cc.SpriteFrame:createWithTexture(textureDog, rect)
        rect = cc.rect(frameWidth, 0, frameWidth, frameHeight)
        local frame1 = cc.SpriteFrame:createWithTexture(textureDog, rect)
        
        
        local spriteDog = cc.Sprite:createWithSpriteFrame(frame0)
        spriteDog.isPaused = false
        --spriteDog.setAnchorPoint(0,0)
        spriteDog:setPosition(origin.x, origin.y + visibleSize.height / 4 * 3)
--[[
        local animFrames = CCArray:create()

        animFrames:addObject(frame0)
        animFrames:addObject(frame1)
]]--
        local actionr = cc.ScaleTo:create(0.15,0.5,0.5,1)
        --local actionback = actionr:reverse()
        local actionback = cc.ScaleTo:create(0.25,1)
        local animation = cc.Animation:createWithSpriteFrames({frame0,frame1}, 0.5)
        local animate = cc.Animate:create(animation);
        --spriteDog:runAction(cc.RepeatForever:create(animate))
        local seq = cc.Sequence:create(actionr,actionback)
        --spriteDog:runAction(seq)
        spriteDog:runAction(cc.RepeatForever:create(cc.Spawn:create(animate,seq)))
        -- moving dog at every frame
        local function tick()
            if spriteDog.isPaused then return end
            local x, y = spriteDog:getPosition()
            if x > origin.x + visibleSize.width then
                x = origin.x
            else
                x = x + 1
            end

            spriteDog:setPositionX(x)
        end

        schedulerID = cc.Director:getInstance():getScheduler():scheduleScriptFunc(tick, 0, false)

        return spriteDog
    end
    
    local function createMgrPicture()
        local i_donot_know = {}
        local mgg = require("src.manager")
        mgg.init(i_donot_know,"dog.png")
--        i_donot_know.sprite:setPosition(origin.x + visibleSize.width / 2, origin.y + visibleSize.height / 2)
        i_donot_know.sprite:setAnchorPoint(0,0)
        i_donot_know.sprite:setPosition(0,0)
        return i_donot_know
    end

    -- create farm
    local function createLayerFarm()
        local layerFarm = cc.Layer:create()

        -- add in farm background
        local socket = require "socket"
        local t0 = socket.gettime()
        local bg = cc.Sprite:create("farm.jpg")
        local t1 = socket.gettime()
        print("used time: "..t1-t0.."ms") 
        
        local abcbg = cc.Sprite:create("abc.png")
        local t2 = socket.gettime()
        print("png used time: "..t2-t1.."ms") 
        
        bg:setPosition(origin.x + visibleSize.width / 2 + 80, origin.y + visibleSize.height / 2)
        layerFarm:addChild(bg)
        
        -- add land sprite
        for i = 0, 3 do
            for j = 0, 1 do
                local spriteLand = cc.Sprite:create("land.png")
                spriteLand:setPosition(200 + j * 180 - i % 2 * 90, 10 + i * 95 / 2)
                layerFarm:addChild(spriteLand)
            end
        end

        -- add crop
        local frameCrop = cc.SpriteFrame:create("crop.png", cc.rect(0, 0, 105, 95))
        for i = 0, 3 do
            for j = 0, 1 do
                local spriteCrop = cc.Sprite:createWithSpriteFrame(frameCrop);
                spriteCrop:setPosition(10 + 200 + j * 180 - i % 2 * 90, 30 + 10 + i * 95 / 2)
                layerFarm:addChild(spriteCrop)
            end
        end

        -- add moving dog
        local spriteDog = creatDog()
        local spriteMgr = createMgrPicture()
        layerFarm:addChild(spriteDog)
        layerFarm:addChild(spriteMgr.sprite)
        -- handing touch events
        local touchBeginPoint = nil
        local function onTouchBegan(touch, event)
            local location = touch:getLocation()
            --cclog("onTouchBegan: %0.2f, %0.2f", location.x, location.y)
            touchBeginPoint = {x = location.x, y = location.y}
            spriteDog.isPaused = true
            -- CCTOUCHBEGAN event must return true
            return true
        end

        local function onTouchMoved(touch, event)
            local location = touch:getLocation()
            --cclog("onTouchMoved: %0.2f, %0.2f", location.x, location.y)
            if touchBeginPoint then
                local cx, cy = layerFarm:getPosition()
                layerFarm:setPosition(cx + location.x - touchBeginPoint.x,
                                      cy + location.y - touchBeginPoint.y)
                touchBeginPoint = {x = location.x, y = location.y}
            end
        end

        local function onTouchEnded(touch, event)
            local location = touch:getLocation()
            --cclog("onTouchEnded: %0.2f, %0.2f", location.x, location.y)
            touchBeginPoint = nil
            spriteDog.isPaused = false
        end

        local listener = cc.EventListenerTouchOneByOne:create()
        listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN )
        listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED )
        listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED )
        local eventDispatcher = layerFarm:getEventDispatcher()
        eventDispatcher:addEventListenerWithSceneGraphPriority(listener, layerFarm)
        
        local function onNodeEvent(event)
           if "exit" == event then
               cc.Director:getInstance():getScheduler():unscheduleScriptEntry(schedulerID)
           end
        end
        layerFarm:registerScriptHandler(onNodeEvent)

        return layerFarm
    end


    -- create menu
    local function createLayerMenu()
        local layerMenu = cc.Layer:create()

        local menuPopup, menuTools, effectID

        local function menuCallbackClosePopup()
            -- stop test sound effect
            cc.SimpleAudioEngine:getInstance():stopEffect(effectID)
            menuPopup:setVisible(false)
        end

        local function menuCallbackOpenPopup()
            -- loop test sound effect
            local effectPath = cc.FileUtils:getInstance():fullPathForFilename("effect1.wav")
            effectID = cc.SimpleAudioEngine:getInstance():playEffect(effectPath)
            menuPopup:setVisible(true)
        end

        -- add a popup menu
        local menuPopupItem = cc.MenuItemImage:create("menu2.png", "menu2.png")
        menuPopupItem:setPosition(0, 0)
        menuPopupItem:registerScriptTapHandler(menuCallbackClosePopup)
        menuPopup = cc.Menu:create(menuPopupItem)
        menuPopup:setPosition(origin.x + visibleSize.width / 2, origin.y + visibleSize.height / 2)
        menuPopup:setVisible(false)
        layerMenu:addChild(menuPopup)
        
        -- add the left-bottom "tools" menu to invoke menuPopup
        local menuToolsItem = cc.MenuItemImage:create("menu1.png", "menu1.png")
        menuToolsItem:setPosition(0, 0)
        menuToolsItem:registerScriptTapHandler(menuCallbackOpenPopup)
        
        menuTools = cc.Menu:create(menuToolsItem)
        local itemWidth = menuToolsItem:getContentSize().width
        local itemHeight = menuToolsItem:getContentSize().height
        menuTools:setPosition(origin.x + itemWidth/2, origin.y + itemHeight/2)
        
        local function onMenuGetClicked()
            local xhr = cc.XMLHttpRequest:new()
            --xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_DOCUMENT
            xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
            xhr.timeout = 3000
            --xhr:open("GET", "http://httpbin.org/get")
            xhr:setRequestHeader("Content-Type","application/soap+xml;charset=utf-8")
            xhr:open("POST","http://27.154.242.238:9087/ussWebservice/ws/rs/marketPoint/addChangePresentXmYZDD")
            
            --xhr:setRequestHeader("Content-Type","your special")
            --xhr:open("POST","http://httpbin.org/post")
            local function onReadyStateChangee()
                local statusString = "Http Status Code:"..xhr.statusText
                print(xhr.response)
            end

            xhr:registerScriptHandler(onReadyStateChangee)
            --xhr:send()
            --xhr:send("visitor=cocos2d&TestSuite=Extensions Test/NetworkTest")
            xhr:send("<TmChange><userId>100053763</userId><userCode>300582</userCode><qtyChange>1</qtyChange><ruleId>10000425</ruleId><presentId>10003200</presentId></TmChange>")
        end
        

--        local layerRequest = cc.Layer:create()
        local menuRequest = cc.Menu:create()
        menuRequest:setPosition(cc.p(itemWidth * 1.5,itemHeight * 1.5))
        local labelGet = cc.Label:createWithTTF("Test Get Version2”, s_arialPath, 22)
        --local labelGet cc.LabelTTF:create("Test Get",s_arialPath,20)
        local itemGet  =  cc.MenuItemLabel:create(labelGet)
        itemGet:registerScriptTapHandler(onMenuGetClicked)
        menuRequest:addChild(itemGet)
--        layerRequest:addChild(menuRequest)
        
        layerMenu:addChild(menuTools)
        layerMenu:addChild(menuRequest)
        print(labelGet)
        --labelGet:setAnchorPoint(cc.p(0.5, 0.5))
        return layerMenu
    end

    -- play background music, preload effect

    -- uncomment below for the BlackBerry version
    local bgMusicPath = nil 
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
        bgMusicPath = cc.FileUtils:getInstance():fullPathForFilename("res/background.caf")
    else
        bgMusicPath = cc.FileUtils:getInstance():fullPathForFilename("res/background.mp3")
    end
    cc.SimpleAudioEngine:getInstance():playMusic(bgMusicPath, true)
    local effectPath = cc.FileUtils:getInstance():fullPathForFilename("effect1.wav")
    cc.SimpleAudioEngine:getInstance():preloadEffect(effectPath)
    
    local function create_draw_layer()

        local brushes = {}
        local draw_layer = cc.Layer:create()
        local draw_on = cc.RenderTexture:create(visibleSize.width,visibleSize.height,cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A8888)  -- 576*720
        draw_on:retain()
    --    draw_on:setAnchorPoint(0,0)
        draw_on:setPosition(cc.p(visibleSize.width/2,visibleSize.height/2))
        
        draw_layer:addChild(draw_on,-1)
        
        local function clearImage()
            draw_on:clear( math.random(), math.random(), math.random(), math.random() )
        end
        
        local function onTouchesMoved(touches, event)
            local start = touches[1]:getLocation()
            local ended = touches[1]:getPreviousLocation()
            
            draw_on:begin()
            local distance = cc.pGetDistance(start,ended)
            if distance > 1 then
                brushes = {}
                local d = distance
                local i = 0
                
                for i=0,d -1 do
                    local sprite = cc.Sprite:create("res/fire.png")
                    sprite:setColor(cc.c3b(255,0,0))
                    sprite:setOpacity(20)
                    brushes[i+1] = sprite
                end
                
                for i= 0,d -1 do
                    local difx = ended.x - start.x
                    local dify = ended.y - start.y
                    local delta = i/distance
                    brushes[i+1]:setPosition(cc.p(start.x+(difx*delta), start.y+(dify*delta)))
                    brushes[i+1]:setRotation(math.random(0,359))
                    local r = math.random(0,49) / 50.0 + 0.25
                    brushes[i+1]:setScale(r)
                    
                    brushes[i+1]:setColor(cc.c3b(math.random(0,126)+128,255,255))
                    brushes[i+1]:visit()
                end
            end
            draw_on:endToLua()
        end
        
        local listener = cc.EventListenerTouchAllAtOnce:create()
        listener:registerScriptHandler(onTouchesMoved,cc.Handler.EVENT_TOUCHES_MOVED)
        local eventDispatcher = draw_layer:getEventDispatcher()
        eventDispatcher:addEventListenerWithSceneGraphPriority(listener,draw_layer)
        clearImage()
        return draw_layer
    end
    
    
    -- run
    local sceneGame = cc.Scene:create()
    sceneGame:addChild(createLayerFarm())
    sceneGame:addChild(createLayerMenu())
    --sceneGame:addChild(create_draw_layer())
	
	if cc.Director:getInstance():getRunningScene() then
		cc.Director:getInstance():replaceScene(sceneGame)
	else
		cc.Director:getInstance():runWithScene(sceneGame)
	end

end


xpcall(main, __G__TRACKBACK__)

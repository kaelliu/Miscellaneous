require "Cocos2d"
require "Cocos2dConstants"
require "src/testResource"
-- cclog
cclog = function(...)
    print(string.format(...))
end
  
-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
    cclog("----------------------------------------")
    cclog("LUA ERROR: " .. tostring(msg) .. "\n")
    cclog(debug.traceback())
    cclog("----------------------------------------")
end

local function main()
    collectgarbage("collect")
    -- avoid memory leak
    collectgarbage("setpause", 100)
    local valstep = collectgarbage("setstepmul", 1000)
    
    local uid
    local function sUid(u)
        uid = u.uid
    end
    
    local aid
    local function sAid(u)
        aid = u.aid
    end
    
    local ucode
    local function sUcode(u)
        ucode = u.uc
    end

    local luaoc = require "luaoc"
    luaoc.callStaticMethod("RootViewController", "registeScriptHandler", {setUid = sUid,setUcode = sUcode,setAid = sAid})
    cc.FileUtils:getInstance():addSearchPath("src");
    cc.FileUtils:getInstance():addSearchPath("res");
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local origin = cc.Director:getInstance():getVisibleOrigin()
    
    local version = "https://raw.github.com/kaellzt/AssetsManager/master/version" .. aid
    local zip = "https://raw.github.com/kaellzt/AssetsManager/master/package"..aid..".zip"
    
    local labelGet = cc.Label:createWithTTF("loading:", s_arialPath, 22)
    
    -- asset manager start
    local pathToSave          = ""
    pathToSave = createDownloadDir()

    local function onError(errorCode)
        if errorCode == cc.ASSETSMANAGER_NO_NEW_VERSION then
            labelGet:setString("no new version")
        elseif errorCode == cc.ASSETSMANAGER_NETWORK then
            labelGet:setString("network error")
        end
    end

    local function onProgress( percent )
        local progress = string.format("downloading %d%%",percent)
        labelGet:setString(progress)
    end

    local function onSuccess()
        labelGet:setString("downloading ok")
        deleteDownloadDir(pathToSave)
        onNewVersionOk()
    end

    local function getAssetsManager()
        if nil == assetsManager then
            assetsManager = cc.AssetsManager:new(zip,version,
                                           pathToSave)
            assetsManager:retain()
            assetsManager:setDelegate(onError, cc.ASSETSMANAGER_PROTOCOL_ERROR )
            assetsManager:setDelegate(onProgress, cc.ASSETSMANAGER_PROTOCOL_PROGRESS)
            assetsManager:setDelegate(onSuccess, cc.ASSETSMANAGER_PROTOCOL_SUCCESS )
            assetsManager:setConnectionTimeout(3)
        end
        return assetsManager
    end
    
    local function reloadModule( moduleName )
        return require(moduleName)
    end

    -- asset manager end

    local function createLayer()
    	local layerFarm = cc.Layer:create()

    	layerFarm:addChild(labelGet)
    	-- need add origin because scale policy will change visible size depend on policy
    	layerFarm:setPosition(visibleSize.width/2+origin.x,visibleSize.height/2+origin.y)
    	return layerFarm
    end
    
    -- check version and make     

    local sceneLoading = cc.Scene:create()
    sceneLoading:addChild(createLayer())
	
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(sceneLoading)
    else
        cc.Director:getInstance():runWithScene(sceneLoading)
    end

    local function onNewVersionOk()
        local sceneGame = require("game"..aid)
        cc.Director:getInstance():replaceScene(sceneGame)
    end
end


xpcall(main, __G__TRACKBACK__)

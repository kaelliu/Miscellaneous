local mod_test = {hp=100}
-- static module like c?
function mod_test.dostaff(self,a,b)
    self.hp = self.hp + a^b
end

function mod_test:dostaff(a,b) --@return typeOrObject
	self.hp = self.hp + a^b
end

function mod_test.helper(a,b)
    return a-b
end

return mod_test